// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2023.1 (64-bit)
// Tool Version Limit: 2023.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2023 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XSCHARR_H
#define XSCHARR_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xscharr_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
    u16 DeviceId;
    u64 Ctrl_BaseAddress;
} XScharr_Config;
#endif

typedef struct {
    u64 Ctrl_BaseAddress;
    u32 IsReady;
} XScharr;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XScharr_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XScharr_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XScharr_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XScharr_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XScharr_Initialize(XScharr *InstancePtr, u16 DeviceId);
XScharr_Config* XScharr_LookupConfig(u16 DeviceId);
int XScharr_CfgInitialize(XScharr *InstancePtr, XScharr_Config *ConfigPtr);
#else
int XScharr_Initialize(XScharr *InstancePtr, const char* InstanceName);
int XScharr_Release(XScharr *InstancePtr);
#endif

void XScharr_Start(XScharr *InstancePtr);
u32 XScharr_IsDone(XScharr *InstancePtr);
u32 XScharr_IsIdle(XScharr *InstancePtr);
u32 XScharr_IsReady(XScharr *InstancePtr);
void XScharr_EnableAutoRestart(XScharr *InstancePtr);
void XScharr_DisableAutoRestart(XScharr *InstancePtr);

void XScharr_Set_rows(XScharr *InstancePtr, u32 Data);
u32 XScharr_Get_rows(XScharr *InstancePtr);
void XScharr_Set_cols(XScharr *InstancePtr, u32 Data);
u32 XScharr_Get_cols(XScharr *InstancePtr);

void XScharr_InterruptGlobalEnable(XScharr *InstancePtr);
void XScharr_InterruptGlobalDisable(XScharr *InstancePtr);
void XScharr_InterruptEnable(XScharr *InstancePtr, u32 Mask);
void XScharr_InterruptDisable(XScharr *InstancePtr, u32 Mask);
void XScharr_InterruptClear(XScharr *InstancePtr, u32 Mask);
u32 XScharr_InterruptGetEnabled(XScharr *InstancePtr);
u32 XScharr_InterruptGetStatus(XScharr *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
